_$('contentbox').style.display='block';
_$('contentbox').innerHTML = "    <div class='content'>\
      <fieldset>\
        <legend>Request Headers</legend>\
        <table id='header-table'></table>\
		<div><a id='add-header-btn' href='#'>Add Header</a></div>\
      </fieldset>\
      <fieldset class='filter-control'>\
        <legend>Filters</legend>\
        <table id='filter-table'></table>\
        <div><a id='add-filter-btn' href='#'>Add Filter</a></div>\
      </fieldset>\
    </div></div>";
/**
 * Manages a list of rows in the UI.
 *
 * @param table the jquery table element to append the row to.
 */
function RowManager(table, rowFactory) {
  this.table_ = table;
  this.rowFactory_ = rowFactory;
  this.all_rows_ = [];
};

/**
 * Adds a row to the UI if there none exists.
 */
RowManager.prototype.add = function(serializedRecord) {
  var row = this.rowFactory_(serializedRecord);
  row.attachToTable(this.table_);
  var thisRowManager = this;
  row.setDeleteHandler(function() {
    row.detachFromTable();
    var index = thisRowManager.all_rows_.indexOf(row);
    if (index !== -1) {
      thisRowManager.all_rows_.splice(index, 1);
    }
    if (!thisRowManager.all_rows_.length) {
      thisRowManager.add();
    }
  });
  this.all_rows_.push(row);
};

/**
 * Popuplate the rows with a list of serialized records.
 */
RowManager.prototype.populateAll = function(serializedRecordList) {
  this.table_.empty();
  if (serializedRecordList) {
    for (var i = 0, length = serializedRecordList.length; i < length; i++) {
      this.add(serializedRecordList[i]);
    }
  }
  if (!this.all_rows_.length) {
    this.add();
  }
};

/**
 * Serializes the row inputs into a list of JSON records and clear the rows.
 */
RowManager.prototype.serializeAndClear = function() {
  var records = [];
  for (var i = 0, length = this.all_rows_.length; i < length; i++) {
    records.push(this.all_rows_[i].serialize());
  }
  this.all_rows_ = [];
  return records;
};
/**
 * Creates a request header based on the serialized header.
 *
 * @param !serializedHeader the serialized request header value.
 */
function Header(serializedHeader) {
  this.enableChk_ = $('<input type="checkbox" class="check" />');
  this.nameTxt_ = $('<input type="text" placeholder="Name" size="15" />');
  this.valueTxt_ = $('<input type="text" placeholder="Value" size="20" />');
  this.commentTxt_ = $('<input type="text" placeholder="Comment" size="15" />');
  this.deleteBtn_ = $('<button class="delete" />');
  this.headerRow_ = $('<tr>');
  if (!serializedHeader || serializedHeader.enabled) {
    this.enableChk_.attr('checked', 'checked');
  }
  if (serializedHeader) {
    this.nameTxt_.val(serializedHeader.name);
    this.valueTxt_.val(serializedHeader.value);
    this.commentTxt_.val(serializedHeader.comment);
  }
};

/**
 * Serializes the current header values in the input.
 *
 * @return a struct representing the header value.
 */
Header.prototype.serialize = function() {
  return {
    name: this.nameTxt_.val(),
    value: this.valueTxt_.val(),
    comment: this.commentTxt_.val(),
    enabled: this.enableChk_.get(0).checked,
  };
};

/**
 * Adds this header to the UI.
 *
 * @param table the jquery table element to append the header row to.
 */
Header.prototype.attachToTable = function(table) {
  table.append(this.headerRow_.append(
      $('<td>').append(this.enableChk_),
      $('<td>').append(this.nameTxt_),
      $('<td>').append(this.valueTxt_),
      $('<td>').append(this.commentTxt_),
      $('<td>').append(this.deleteBtn_)));
  this.nameTxt_.focus();
};

/**
 * Detaches this header from the UI.
 */
Header.prototype.detachFromTable = function() {
  this.headerRow_.detach();
};

/**
 * Sets the callback handler for the delete row event.
 */
Header.prototype.setDeleteHandler = function(handler) {
  this.deleteBtn_.click(handler);
};
/**
 * Creates a filter based on the serialized filter.
 *
 * @param !serializedFilter the serialized filter value.
 */
function Filter(serializedFilter) {
  this.hostTxt_ = $('<input type="text" placeholder="Add a new hostname pattern. e.g., *.google.com*" size="40" />');
  this.allowOption_ = $('<option value="true">').append('Allow');
  this.blockOption_ = $('<option value="false">').append('Block');
  this.behaviorSelect_ = $('<select>').append(this.allowOption_, this.blockOption_);
  this.commentTxt_ = $('<input type="text" placeholder="Comment" size="15" />');
  this.deleteBtn_ = $('<button class="delete" />');
  this.filterRow_ = $('<tr>');
  if (serializedFilter) {
    this.hostTxt_.val(serializedFilter.host);
    this.behaviorSelect_.val(serializedFilter.behavior);
    this.commentTxt_.val(serializedFilter.comment);
  }
};

/**
 * Serializes the current filter values in the input.
 *
 * @return a struct representing the filter value.
 */
Filter.prototype.serialize = function() {
  return {
    host: this.hostTxt_.val(),
    behavior: this.behaviorSelect_.val(),
    comment: this.commentTxt_.val(),
  };
};

/**
 * Adds this filter to the UI.
 *
 * @param table the jquery table element to append the filter row to.
 */
Filter.prototype.attachToTable = function(table) {
  table.append(this.filterRow_.append(
      $('<td>').append(this.hostTxt_),
      $('<td>').append(this.behaviorSelect_),
      $('<td>').append(this.commentTxt_),
      $('<td>').append(this.deleteBtn_)));
  this.hostTxt_.focus();
};

/**
 * Detaches this filter from the UI.
 */
Filter.prototype.detachFromTable = function() {
  this.filterRow_.detach();
};

/**
 * Sets the callback handler for the delete row event.
 */
Filter.prototype.setDeleteHandler = function(handler) {
  this.deleteBtn_.click(handler);
};
/**
 * Manages a profile.
 */
function Profile(profileIndex) {
  this.profileName_ = 'Profile ' + (profileIndex + 1);
  this.profileTab_ = $('<td class="profile">').append(this.profileName_);
  this.profileIndex_ = profileIndex;
  this.profileRecord_ = {};
};

/**
 * Gets the serialized profile record.
 */
Profile.prototype.getRecord = function() {
  return this.profileRecord_;
};

/**
 * Sets the serialized profile record.
 */
Profile.prototype.setRecord = function(profileRecord) {
  this.profileRecord_ = profileRecord;
};

/**
 * Attaches this profile UI to the profile row.
 *
 * @param profileRow the profile row elemenet to attach to.
 */
Profile.prototype.attachTo = function(profileRow) {
  profileRow.append(this.profileTab_);
};

/**
 * Sets whether this profile is selected.
 */
Profile.prototype.setSelected = function(isSelected) {
  var className = isSelected ? 'profile profile-selected' : 'profile';
  this.profileTab_.attr('class', className);
};

/**
 * Sets the handler for when the profile is selected.
 * The handler is a callback with the signature function(profileIndex).
 */
Profile.prototype.setSelectHandler = function(handler) {
  this.profileTab_.click((function(profileIndex) {
    return function() {
      handler(profileIndex);
    };
  })(this.profileIndex_));
};
var NUM_PROFILES = 4;
var profiles = [];
var selectedProfile = 0;
var initialized = false;
var headerManager = new RowManager($('#header-table'), function(record) {
  return new Header(record);
});
var filterManager = new RowManager($('#filter-table'), function(record) {
  return new Filter(record);
});
var dataStore = localStorage;

/**
 * Save the current profile in the UI to the localStorage.
 */
function saveProfile(selectedProfile) {
  profiles[selectedProfile].setRecord({
    headers: headerManager.serializeAndClear(),
    filters: filterManager.serializeAndClear(),
  });
  var profileRecords = [];
  for (var i = 0; i < NUM_PROFILES; ++i) {
    profileRecords.push(profiles[i].getRecord());
  }
  dataStore.profiles = JSON.stringify(profileRecords);
};

/**
 * Selects the profile at the given index.
 */
function changeProfile(newProfileIndex) {
  saveProfile(selectedProfile);
  selectedProfile = newProfileIndex;

  // Updates the UI for the selected tab.
  for (var i = 0; i < NUM_PROFILES; ++i) {
    profiles[i].setSelected(i == selectedProfile);
  }
  populateProfile(profiles[selectedProfile].getRecord());
  dataStore.selectedProfile = selectedProfile;
};

/**
 * Populates the UI based on the profile record.
 */
function populateProfile(profileRecord) {
  headerManager.populateAll(profileRecord.headers);
  filterManager.populateAll(profileRecord.filters);
}

/**
 * Adds the profiles row.
 */
function initProfileRow() {
  var profileRow = $('<tr>');
  for (i = 0; i < NUM_PROFILES; ++i) {
    // Add the profile UI.
    var profile = new Profile(i);
    profile.attachTo(profileRow);
    profile.setSelectHandler(function(profileIndex) {
      changeProfile(profileIndex);
    });
    profiles.push(profile);
  }
  $('#profile-table').append(profileRow);
};

/**
 * Loads the headers value from the dataStore.
 */
function initialize() {
  initProfileRow();
  // Load the profiles.
  if (dataStore.profiles) {
    var profilesRecord = $.parseJSON(dataStore.profiles);
    for (var i = 0, length = profilesRecord.length; i < length; ++i) {
      profiles[i].setRecord(profilesRecord[i]);
    }
  }

  if (dataStore.selectedProfile) {
    selectedProfile = dataStore.selectedProfile;
  }
  profiles[selectedProfile].setSelected(true);
  populateProfile(profiles[selectedProfile].getRecord());

  $('#add-header-btn').click(function() {
    headerManager.add();
  });
  $('#add-filter-btn').click(function() {
    filterManager.add();
  });

  initialized = true;
};

onunload = function() {
  if (initialized) {
    saveProfile(selectedProfile);
  }
};

initialize();