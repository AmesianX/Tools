$(document).ready(function() {
	$(".Tab").hide();
	$("#T_Coder").show();
});
var tab = _$("tab");
var encoder =_$("encoder");
var decoder = _$("decoder");
var cracker = _$("cracker");
var TBox = _$("TBox");
tab.onchange = function(){
	$(".Tab").hide();
	$("#T_"+tab.options[tab.selectedIndex].value).show();
	$('#contentbox').hide();
}
getselect = function(){
	var textval = (TBox.selectionStart != TBox.selectionEnd) ? TBox.value.substring(TBox.selectionStart, TBox.selectionEnd): $("#TBox").attr("value");
	return textval;
}
en = function(){
	Encoder(getselect(),encoder.options[encoder.selectedIndex].value);
}
encoder.onchange = encoder.ondblclick = en;
de = function(){
	Decoder(getselect(),decoder.options[decoder.selectedIndex].value);
}
decoder.onchange = decoder.ondblclick = de;
cr = function(){
	Cracker(getselect(),cracker.options[cracker.selectedIndex].value);
}
cracker.onchange = cracker.ondblclick = cr;
