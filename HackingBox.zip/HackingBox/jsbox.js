_$("owntab").onchange = function(){
	var tabval = _$("owntab").options[_$("owntab").selectedIndex].value;
	if (tabval == 'setNew') {
		alert(1);return;
	}else if (tabval == '') {
		alert('no Js');return;
	}
	
	if (tabval.indexOf('Tab_') == 0){
	chrome.tabs.getSelected(null,function(tab) {
		chrome.tabs.executeScript(tab.id, {file: "/jsbox/"+tabval+".js"});
	});
	}else{
		(function() {
 		 var ga = document.createElement('script');
 		 ga.type = 'text/javascript';
 		 ga.async = true;
 		 ga.src = '/jsbox/'+tabval+'.js';
  		var s = document.getElementsByTagName('script')[0];
  		s.parentNode.insertBefore(ga, s);
		})();
	}
}