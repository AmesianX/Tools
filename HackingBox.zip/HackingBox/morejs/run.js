function setcookie(){
  var URL = '';
  var mycookie;
  chrome.tabs.getSelected(null,function(tab) {  
       URL = tab.url;
    console.log(tab);
    mycookie = prompt("Input Your Cookie On "+URL);
    inject(mycookie,URL);
  });
}
function inject(cookies,URL){
	if(!cookies){
		$('status').innerHTML = 'No Cookies.';
		return;
	}
	if (!chrome.cookies) {
	  chrome.cookies = chrome.experimental.cookies;
	}
	
	d = new Date();
	e = d.setTime(d.getTime()/1000+365*70*24*3600); //second
	
	
	domain = URL.split('/')[2];
	url = URL.split('/')[0] + '//' + domain;
	
	cc = cookies.split(';');
	for(i in cc){
		c = cc[i].replace(/^\s+|\s+$/g, "");
		if(!c) continue;
		k = c.split('=')[0].replace(/^\s+|\s+$/g, "").replace(' ', '+');
		v = c.split('=')[1].replace(/^\s+|\s+$/g, "").replace(' ', '+');
		chrome.cookies.set({
			'url': url,
			'name': k,
			'value': v,
			'path': '/',
			'domain': domain,
			'expirationDate': e,
		});
	};
	alert('OK.');
	
}
createMenu('[Base64 Encode]',base64encode);
createMenu('[Base64 Decode]',base64de);
createMenu('[URI Encode]',encodeURIComponent);
createMenu('[URI Decode]',decodeURIComponent);
createMenu('[HTML Entities]',htmlentities);
createMenu('[HTML Entity Decode]',htmlentitydecode);
createMenu('[JSUnicode]',jsunic);
createMenu('[JSUnicode Decode]',jsde);
createMenu('-');
createMenu('Edit Cookie',setcookie);