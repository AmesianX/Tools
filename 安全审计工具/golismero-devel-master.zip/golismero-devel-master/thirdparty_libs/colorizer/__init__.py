from .initialise import init, deinit, reinit
from .ansi import Fore, Back, Style
from .ansitowin32 import AnsiToWin32
from .termcolor import *

VERSION = '0.2.5'

init()