"""
Text manipulation and analysis API.
"""
