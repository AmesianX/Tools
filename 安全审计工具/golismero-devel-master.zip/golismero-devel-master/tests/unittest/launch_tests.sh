#!/bin/sh
py.test 
