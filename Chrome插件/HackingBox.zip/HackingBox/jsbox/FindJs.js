﻿_$('contentbox').style.display ='block';
_$('contentbox').innerHTML = '<button id="FindAll">列出所有引用内容</button><button id="FindAllJs">列出所有Js</button>';
_$('FindAll').onclick=function(){
	run("for (var i=0,tags=document.querySelectorAll('[src],[data],[rel=stylesheet],[href]'),tag;tag=tags[i];i++){	document.write('[' + tag.localName+'] >> '+(tag.src||tag.href) + '<br />');}");
}
_$('FindAllJs').onclick=function(){
	run("for (var i=0,tags=document.querySelectorAll('script[src]'),tag;tag=tags[i];i++){	document.write('[' + tag.localName+'] >> '+(tag.src||tag.href) + '<br />');}");
}

function run(code){
	chrome.tabs.getSelected(null,function(tab) {
		chrome.tabs.executeScript(tab.id, {code: code});
	});
}