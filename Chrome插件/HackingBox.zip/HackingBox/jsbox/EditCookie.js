var URL ;
chrome.tabs.getSelected(null,function(tab) {  
    URL = tab.url;
	_$('domain').value = URL.split('/')[2];
});
_$('contentbox').style.display ='block';
_$('contentbox').innerHTML = '<input type="text" placeholder="Domain" id="domain"><input type="button" id="submit" value="Submit"><br /><textarea id="cookie" style="margin: 2px; width: 97%; height: 88px;" placeholder="Cookies"></textarea><br /><span class="help" id="status"></span>';
function inject(cookies){
	if(!cookies){
		$('status').innerHTML = 'No Cookies.';
		return;
	}
	if (!chrome.cookies) {
	  chrome.cookies = chrome.experimental.cookies;
	}
	
	d = new Date();
	e = d.setTime(d.getTime()/1000+365*70*24*3600); //second
	
	
	domain = URL.split('/')[2];
	if(_$('domain').value != domain){
		_domain = $('domain').value;
	}
	url = URL.split('/')[0] + '//' + domain;
	
	cc = cookies.split(';');
	for(i in cc){
		c = cc[i].replace(/^\s+|\s+$/g, "");
		if(!c) continue;
		k = c.split('=')[0].replace(/^\s+|\s+$/g, "").replace(' ', '+');
		v = c.split('=')[1].replace(/^\s+|\s+$/g, "").replace(' ', '+');
		chrome.cookies.set({
			'url': url,
			'name': k,
			'value': v,
			'path': '/',
			'domain': $('domain').value,
			'expirationDate': e,
		});
	};
	_$('status').innerHTML = 'OK.';
	
}
	_$('submit').addEventListener('click', function () {
		inject(_$('cookie').value);
	});
