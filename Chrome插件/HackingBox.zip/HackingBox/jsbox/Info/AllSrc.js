for (var i=0,tags=document.querySelectorAll('[src],[data],[rel=stylesheet],[href]'),tag;tag=tags[i];i++){
	document.write('[' + tag.localName+'] >> '+(tag.src||tag.href) + '<br />');
}