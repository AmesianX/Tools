﻿_$('contentbox').style.display ='block';
_$('contentbox').innerHTML = '<div id="all"><div id="inputC"><input id="chr" type="text">	</div><div id="output">	<input id="eight" type="text" style="display:none" >\
	<input id="url" type="text" style="display:none" >\
	<input id="htmlC" type="text" style="display:none" >\
	<input id="htmlT" type="text" style="display:none" >\
	<input id="unicodeC" type="text" style="display:none" >\
	<input id="fromCharCode" type="text" style="display:none" >\
	<input id="hex2" type="text" style="display:none" >\
	<input id="hex3" type="text" style="display:none" >\
	<input id="hex4" type="text" style="display:none" >\
</div>\
	</div>\
';
_$('chr').onkeyup = function(){
	toS();
}
function to(_chr){
	var _ten = _chr.charCodeAt(0);
	var _hex = _ten.toString(16);
	var _eight = _ten.toString(8);
	
	return {
		"ten":_ten,
		"hex":_hex,
		"eight":_eight
	};
}

function toS(){
	var _chr = document.getElementById("chr").value;
	var _eight = document.getElementById("eight");
	var _url = document.getElementById("url");
	var _html = document.getElementById("htmlC");
	var _htmlt = document.getElementById("htmlT");
	var _unicode = document.getElementById("unicodeC");
	var _fcc = document.getElementById("fromCharCode");
	var _hex2 = document.getElementById("hex2");
	var _hex3 = document.getElementById("hex3");
	var _hex4 = document.getElementById("hex4");
	
	_htmlt.style.display = "none";
	_eight.style.display = "none";
	_url.style.display = "none";
	_html.style.display = "none";
	_unicode.style.display = "none";
	_fcc.style.display = "none";
	_hex2.style.display = "none";
	_hex3.style.display = "none";
	_hex4.style.display = "none";
	if(_chr.length<=0){
		return;
	}
			
	var html_="",htmlt_="";
		eight_="",url_="",
		unicode_="",fcc_="",
		oji_="",
		hex2_="",hex3_="";hex4_="0x"
	if(/.*[\u4e00-\u9fa5]+.*$/.test(_chr)!=true){ 
		for(var i=0;i<_chr.length;i++){
			var tmp = _chr[i];
			var data = to(tmp);
			eight_ += '\\' + data.eight;
			html_ += '&#x' + data.hex + ';';
			htmlt_ += '&#' + data.ten + ';';
			url_ += '%' + data.hex;
			unicode_ += '\\u00' + data.hex;
			fcc_ += data.ten + ',';
			hex2_ += '\\x' + data.hex;
			hex3_ += '0x' + data.hex + ' ';
			hex4_ += data.hex;
		}
		fcc_ = fcc_.slice(0,-1);
		fcc_ = 'String.fromCharCode(' + fcc_ + ')';
		
		_eight.value = eight_;
		_eight.style.display='';
		
		_url.value = url_;
		_url.style.display = "";
		
		_html.value = html_;
		_html.style.display = "";
		
		_htmlt.value = htmlt_;
		_htmlt.style.display = "";
		
		_unicode.value = unicode_;
		_unicode.style.display = "";
		
		_fcc.value = fcc_;
		_fcc.style.display = "";
		
		_hex2.value = hex2_;
		_hex2.style.display = "";
		
		_hex3.value = hex3_;
		_hex3.style.display = "";

		_hex4.value = hex4_;
		_hex4.style.display = "";
	}else{
		for(var i=0;i<_chr.length;i++){
			var tmp = _chr[i];
			var data = to(tmp);
			html_ += '&#x' + data.hex + ';';
			htmlt_ += '&#' + data.ten + ';';
			if(_chr.charCodeAt(i)<127){
				unicode_ += '\\u00' + data.hex;
			}else{
				unicode_ += '\\u' + data.hex;
			}
			fcc_ += data.ten + ',';
		}
		fcc_ = fcc_.slice(0,-1);
		fcc_ = 'String.fromCharCode(' + fcc_ + ')';
		
		_fcc.value = fcc_;
		_fcc.style.display="";
		
		_html.value = html_;
		_html.style.display = "";
		
		_htmlt.value = htmlt_;
		_htmlt.style.display = "";
		
		_unicode.value = unicode_;
		_unicode.style.display = "";
	}
}
function jsunic(_chr){
	var unicode_ = '';
	for(var i=0;i<_chr.length;i++){
		var tmp = _chr[i];
		var data = to(tmp);
		if(_chr.charCodeAt(i)<127){
			unicode_ += '\\u00' + data.hex;
		}else{
			unicode_ += '\\u' + data.hex;
		}
	}
	return unicode_;
}