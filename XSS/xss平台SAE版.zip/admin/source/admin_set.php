<?php
/**
 * admin_set.php 系统管理
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');

$act=Val('act','GET');

$where='';
switch($act){
	case 'set_submit':
    	if(! $user->CheckToken(Val('token','POST'))) ShowError('操作失败');
		$appid=trim(Val('appid','POST'));
   		$appsecret=trim(Val('appsecret','POST'));
   		$token=trim(Val('wx_token','POST'));
		$db=DBConnect();
		$values=array(
			'appid'=>$appid,
			'appsecret'=>$appsecret,
			'token'=>$token
		);
		$db->AutoExecute(Tb('wx'),$values,'UPDATE');
    	ShowSuccess('修改成功',URL_ROOT.'/admin/index.php?do=admin_set');
		break;
	default:
		$db=DBConnect();
		$data=$db->FirstRow("SELECT `appid`,`appsecret`,`token` FROM ".Tb('wx'));
		$smarty=InitSmarty(1);
    	$smarty->assign('data',$data);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->display('admin_set.html');
		break;
}
?>