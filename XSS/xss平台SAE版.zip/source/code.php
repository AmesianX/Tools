<?php
/**
 * code.php 代码文件
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');
//输入文件格式为js
header("Content-type: application/x-javascript");
header("Cache-Control: nocache");
header("Pragma: no-cache");

//查询所属项目
$id=Val('id','GET',1);
$urlKey=Val('urlKey','GET');
$db=DBConnect();
$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE id='{$id}' OR urlKey='{$urlKey}'");

//无此项目不显示任何内容
if(empty($project)) exit();

if(strlen($project['target'])>0){//目标域名不为空(默认为空关闭判断)
	
	//直接访问等无referer的情况不显示任何内容
	if(empty($_SERVER['HTTP_REFERER'])) exit();
	
	//获取目标域名
	$http_referer=$_SERVER['HTTP_REFERER'];
	$referers=@parse_url($http_referer);
	$domain=$referers['host']?$referers['host']: '';
	$domain=StripStr($domain);
	
	//来源域名不包含目标域名则不显示任何内容，可以填写".cn"，"."可以匹配所有域名和ip，可以默认来判断referer为空的开关
    if(!strstr(strtolower($domain),strtolower($project['target'])))exit();
}


$moduleSetKeys=json_decode($project['moduleSetKeys'],true);
/* 模块 begin */
$moduleIds=array();
if(!empty($project['modules'])) $moduleIds=json_decode($project['modules']);
if(!empty($moduleIds)){
	$modulesStr=implode(',',$moduleIds);
	$modules=$db->Dataset("SELECT * FROM ".Tb('module')." WHERE id IN ($modulesStr)");
	if(!empty($modules)){
		foreach($modules as $module){
			$module['code']=str_replace('{projectId}',$project['urlKey'],$module['code']);
			//module里是否有配置的参数
			if(!empty($module['setkeys'])){
				$setkeys=json_decode($module['setkeys'],true);
				foreach($setkeys as $setkey){
					$module['code']=str_replace('{set.'.$setkey.'}',$moduleSetKeys["setkey_{$module[id]}_{$setkey}"],$module['code']);
				}
			}
			echo htmlspecialchars_decode($module['code'],ENT_QUOTES);
		}	
	}
}
/* 模块 end */
/* 项目自定义代码 */
echo htmlspecialchars_decode($project['code'],ENT_QUOTES);
?>