<?php
/**
 * global.func.php 公共方法
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');

/**邀请码注册定向**/
function UrlInvite($inviteKey){
	return URL_ROOT.(URL_REWRITE ? "/register/{$inviteKey}" : "/index.php?do=register&key={$inviteKey}");
}

/**新浪短网址**/
function shorturl($long_url){
	$apiKey='1681459862';//要修改这里的key再测试哦
	$apiUrl='http://api.t.sina.com.cn/short_url/shorten.json?source='.$apiKey.'&url_long='.$long_url;
	$response = file_get_contents($apiUrl);
	$json = json_decode($response);
	return $json[0]->url_short;
}

/**新浪短网址转长网址**/
function expandurl($short_url){
	$apiKey='1681459862';//要修改这里的key再测试哦
	$apiUrl='http://api.t.sina.com.cn/short_url/expand.json?source='.$apiKey.'&url_short='.$short_url;

	$response = file_get_contents($apiUrl);
	$json = json_decode($response);
	return $json[0]->url_long;
}

/**发送微信消息**/
function send_wx($touser,$content){
    require_once(ROOT_PATH.'/wx/custom.php');
    send_custom($touser,$content);
}

/**获取纯真ip地址**/
function get_ip_full($ip){
    require_once(ROOT_PATH.'/ip/ip.php');
    return convertip_full($ip);
}

/**网址与地址转换**/
function get_ip_address($ip) {
    $info = json_decode(file_get_contents('http://ip.taobao.com/service/getIpInfo.php?ip='.$ip));
    $data = $info->data;
    if ($info->code == 0) {
        $TaobaoAddress="{$data->country}-{$data->region}-{$data->area}-{$data->city}-{$data->county}-{$data->isp}";
        return "{$TaobaoAddress}";
    } else {
        return $data;
    }
}
/**获取客户端ip**/
function get_ip() {
    $realip = ''; //设置默认值
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $realip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
		$realip = $_SERVER['HTTP_CLIENT_IP'];
	} else {
		$realip = $_SERVER['REMOTE_ADDR'];
	}
	preg_match('/^((?:\d{1,3}\.){3}\d{1,3})/',$realip,$match);
	return $match?$match[0]:false;
}
?>