<?php
/**
 * index.php 首页
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');


//未登陆不跳转到登陆界面，显示404页面
//if($user->userId<=0) $user->ToLogin();
if($user->userId<=0){
    @header('Location: '.URL_ROOT.'/index.html');
    exit;
}



include('common.php');


$smarty=InitSmarty();
$smarty->assign('do',$do);
$smarty->assign('show',$show);
$smarty->assign('url',$url);
$smarty->assign('projects',$projects);
$smarty->assign('modules',$modules);
$smarty->display('index.html');
?>