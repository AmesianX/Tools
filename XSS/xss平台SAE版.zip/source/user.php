<?php
/**
 * user.php 用户管理
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');

if($user->userId<=0) ShowError('未登录或已超时',$url['login'],'重新登录');

$act=Val('act','GET');
$id=$user->userId;

switch($act){
	case 'set':
    $db=DBConnect();
    $data=$db->FirstRow("SELECT `userPwd` FROM `".Tb('user')."` where `id`='{$id}'");
    $password=trim(Val('password','POST'));
    $password1=trim(Val('password1','POST'));
    $password2=trim(Val('password2','POST'));
    if(OCEncrypt($password)==$data['userPwd']){
        if($password1==$password2){
            $values=array('userPwd'=>OCEncrypt($password1));
            $db->AutoExecute(Tb('user'),$values,'UPDATE'," id={$id}");
            ShowSuccess('修改成功',URL_ROOT.'/index.php?do=user');
        }else{
            ShowError('修改失败,两次密码不一致',URL_ROOT.'/index.php?do=user');
        }
    }else{
        ShowError('修改失败,请检核对密码',URL_ROOT.'/index.php?do=user');
    }
		break;
    case 'bindstatus':
    $db=DBConnect();
    $data=$db->FirstRow("SELECT `validated` FROM `".Tb('user')."` where `id`='{$id}'");
    $err=$data['validated'];
    $ret = '{ "err":'.$err.'}';
    echo $ret;
    break;
    case 'sendweixin':
    //生成验证码
    $db=DBConnect();
    $existedStrs=$db->FirstColumn("SELECT `validateKey` FROM `".Tb('user')."`");
	$validateKey=ShortUrlCode($existedStrs);
    $values=array('validateKey'=>$validateKey);
    $db->AutoExecute(Tb('user'),$values,'UPDATE'," id={$id}");
    $ret = '{ "err":-1,"msg":"'.$validateKey.'"}';
    echo $ret;
    break;
	default:
        include('common.php');
		$smarty=InitSmarty();
    	$smarty->assign('show',$show);
    	$smarty->assign('url',$url);
    	$smarty->assign('projects',$projects);
    	$smarty->assign('modules',$modules);
		$smarty->display('user.html');
    break;
}
?>