<?php

function send_custom($touser,$content){
    $tmp=_reply_customer($touser,$content,get_sql_accesstoken());
    if($tmp=='40001'||$tmp=='40014'||$tmp=='42001'||$tmp=='41001'){ 
        update_accesstoken();
        _reply_customer($touser,$content,get_sql_accesstoken());
    }
}


function get_sql_accesstoken(){
    return get_sql_arg('access_token');
}

function get_sql_token(){
	return get_sql_arg('token');
}

function get_sql_userId($validateKey){
    return get_sql_arg('id','oc_user',"`validateKey`='".$validateKey."'");
}

function get_sql_arg($arg,$table='oc_wx',$where=''){
	$mysql = new SaeMysql();
	$sql = "SELECT `".$arg."` FROM `".$table."`";
    if(!empty($where)){
        $sql.=" WHERE ".$where;
    }
	$data = $mysql->getLine( $sql );
	if ($mysql->errno() != 0)
	{
    	die("Error:" . $mysql->errmsg());
	}
	$mysql->closeDb();
	return $data[$arg];
}

function update_sql_arg($arg,$table='oc_wx',$where=''){
	$mysql = new SaeMysql();
	$sql = "UPDATE `".$table."`"." SET ".$arg;
    if(!empty($where)){
        $sql.=" WHERE ".$where;
    }
    $mysql->runSql($sql);
    if ($mysql->errno() != 0)
    {

        die("Error:" . $mysql->errmsg());
    }
    $mysql->closeDb();
	return;
}


function update_accesstoken(){
    $token=get_http_accesstoken();
	$mysql = new SaeMysql();
	$sql = "UPDATE `oc_wx` SET `access_token` = '".$token."' ;";
	$mysql->runSql($sql);
	if ($mysql->errno() != 0)
	{
    	die("Error:" . $mysql->errmsg());
	}
	$mysql->closeDb();
}


function get_http_accesstoken(){
    
	$mysql = new SaeMysql();
	$sql = "SELECT `appid`,`appsecret` FROM `oc_wx`";
	$data = $mysql->getLine( $sql );
    
	$TOKEN_URL="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$data['appid']."&secret=".$data['appsecret'];
	
	$json=file_get_contents($TOKEN_URL);
    
	$result=json_decode($json);
	
	return $result->access_token;
}


function _reply_customer($touser,$content,$accesstoken){
    
    $data = '{
	    "touser":"'.$touser.'",
	    "msgtype":"text",
	    "text":
	    {
	         "content":"'.$content.'"
	    }
	}';
	
	$url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=".$accesstoken;
	
	$result = https_post($url,$data);
	$final = json_decode($result);
    //sae_debug($final->errcode);
    return  $final->errcode;
}

function https_post($url,$data)
{
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url); 
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($curl);
    if (curl_errno($curl)) {
       return 'Errno'.curl_error($curl);
    }
    curl_close($curl);
    return $result;
}

function startWith($str, $needle) {
    return strpos($str, $needle) === 0;
}
?>