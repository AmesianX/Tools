<?php

$code='';

if(isset($_GET['state'])){
    $code=$_GET['code'];
    print_r(get_http_accesstoken($code));
    echo '<br>';
    echo $_SERVER["HTTP_USER_AGENT"];
}


function get_http_accesstoken($code){
    	//更换成自己的APPID和APPSECRET
	$APPID="wxea03f65f232ae992";
	$APPSECRET="55091918717f5a540873cf95f1bb0af4";
    	
	$TOKEN_URL="https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$APPID."&secret=".$APPSECRET."&code=".$code."&grant_type=authorization_code";
	
	$json=file_get_contents($TOKEN_URL);
    
	$result=json_decode($json);
	
	return $result;
}


?>