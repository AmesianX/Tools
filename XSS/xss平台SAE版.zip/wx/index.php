<?php

$url= 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxea03f65f232ae992&redirect_uri=http://googleweb.sinaapp.com/wx/login.php&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect';

echo "<a href=".$url.">login</a>";
?>