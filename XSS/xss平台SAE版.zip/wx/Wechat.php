<?php
/**
 * 微信公众平台 PHP SDK
 *
 * @author NetPuter <netputer@gmail.com>
 */

  /**
   * 微信公众平台处理类
   */
  class Wechat {

    /**
     * 以数组的形式保存微信服务器每次发来的请求
     *
     * @var array
     */
    private $request;

    /**
     * 初始化，判断此次请求是否为验证请求，并以数组形式保存
     *
     * @param string $token 验证信息
     * @param boolean $debug 调试模式，默认为关闭
     */
    public function __construct($token, $debug = FALSE) {
      if ($this->isValid() && $this->validateSignature($token)) {
        exit($_GET['echostr']);
      }

      $xml = (array) simplexml_load_string($GLOBALS['HTTP_RAW_POST_DATA'], 'SimpleXMLElement', LIBXML_NOCDATA);

       //函数将数组的所有的 KEY 都转换为小写,只是key
      $this->request = array_change_key_case($xml, CASE_LOWER);
      // 将数组键名转换为小写，提高健壮性，减少因大小写不同而出现的问题
    }

    /**
     * 判断此次请求是否为验证请求
     *
     * @return boolean
     */
    private function isValid() {
      return isset($_GET['echostr']);
    }

    /**
     * 判断验证请求的签名信息是否正确
     *
     * @param  string $token 验证信息
     * @return boolean
     */
    private function validateSignature($token) {
        
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];
        		
		$tmpArr = array($token, $timestamp, $nonce);
        // use SORT_STRING rule
		sort($tmpArr, SORT_STRING);
		$tmpStr = implode( $tmpArr );
		$tmpStr = sha1( $tmpStr );
		
		if( $tmpStr == $signature ){
			return true;
		}else{
			return false;
		}
        
    }

    /**
     * 获取本次请求中的参数，不区分大小
     *
     * @param  string $param 参数名，默认为无参
     * @return mixed
     */
    protected function getRequest($param = FALSE) {
      if ($param === FALSE) {
        return $this->request;
      }

      $param = strtolower($param);

      if (isset($this->request[$param])) {
        return $this->request[$param];
      }

      return NULL;
    }

    /**
     * 用户关注事件时触发，用于子类重写
     *
     * @return void
     */
    protected function onSubscribe() {}

    /**
     * 用户取消关注事件时触发，用于子类重写
     *
     * @return void
     */
    protected function onUnsubscribe() {}
      
    /**
     * 收到扫描事件时触发，用于子类重写
     *
     * @return void
     */
    protected function onScan() {}
      
    /**
     * 收到地理位置事件时触发，用于子类重写
     *
     * @return void
     */
    protected function onAutoLocation() {}

    /**
     * 收到点击按钮事件时触发，用于子类重写
     *
     * @return void
     */
    protected function onClick() {}
      
     /**
     * 收到点击网址事件时触发，用于子类重写
     *
     * @return void
     */
    protected function onView() {}
      
    /**
     * 收到文本消息时触发，用于子类重写
     *
     * @return void
     */
    protected function onText() {}

    /**
     * 收到图片消息时触发，用于子类重写
     *
     * @return void
     */
    protected function onImage() {}
    /**
     * 收到语音消息时触发，用于子类重写
     *
     * @return void
     */
    protected function onVoice() {}
    /**
     * 收到视频消息时触发，用于子类重写
     *
     * @return void
     */
      
    protected function onVideo() {}
    /**
     * 收到地理位置消息时触发，用于子类重写
     *
     * @return void
     */
    protected function onLocation() {}

    /**
     * 收到链接消息时触发，用于子类重写
     *
     * @return void
     */
    protected function onLink() {}
      
     /**
     * 收到扫码推事件的事件推送时触发，用于子类重写
     *
     * @return void
     */
     protected function  scancode_push(){}
      
     /**
     * 扫码推事件且弹出“消息接收中”提示框的事件推送时触发，用于子类重写
     *
     * @return void
     */
     protected function  scancode_waitmsg(){}
      
     /**
     * 弹出系统拍照发图的事件推送时触发，用于子类重写
     *
     * @return void
     */
      protected function  pic_sysphoto(){}
      
     /**
     * 弹出拍照或者相册发图的事件推送时触发，用于子类重写
     *
     * @return void
     */
      protected function  pic_photo_or_album(){}
      
     /**
     * 弹出微信相册发图器的事件推送时触发，用于子类重写
     *
     * @return void
     */
      protected function  pic_weixin(){}
      
     /**
     * 弹出地理位置选择器的事件推送时触发，用于子类重写
     *
     * @return void
     */
      protected function  location_select(){}

    /**
     * 收到未知类型消息时触发，用于子类重写
     *
     * @return void
     */
    protected function onUnknown() {}

    /**
     * 回复文本消息
     * @param  string  $content  消息内容
     * @return void
     */
    protected function responseText($content) {
      exit(new TextResponse($this->getRequest('fromusername'), $this->getRequest('tousername'), $content));
    }
      
     /**
     * 回复图片消息
     * @param  string  $mediaId  媒体id
     * @return void
     */
    protected function responseImage($mediaId) {
      exit(new ImageResponse($this->getRequest('fromusername'), $this->getRequest('tousername'), $mediaId));
    }
      
      
      
     /**
     * 回复语音消息
     * @param  string  $mediaId  媒体id
     * @return void
     */
      protected function responseVoice($mediaId) {
        exit(new VoiceResponse($this->getRequest('fromUserName'),$this->getRequest('toUserName'),$mediaId));
    }
      
     /**
     * 回复视频消息
     * @param  string  $mediaId  媒体id
     * @return void
     */
      protected function responseVideo($mediaId) {
        exit(new VideoResponse($this->getRequest('fromUserName'),$this->getRequest('toUserName'),$mediaId));
    }



    /**
     * 回复音乐消息
     *
     * @param  string  $title       音乐标题
     * @param  string  $description 音乐描述
     * @param  string  $musicUrl    音乐链接
     * @param  string  $hqMusicUrl  高质量音乐链接，Wi-Fi 环境下优先使用
     * @param  string  $mediaId  媒体id
     * @return void
     */
    protected function responseMusic($title, $description, $musicUrl, $hqMusicUrl, $mediaId) {
      exit(new MusicResponse($this->getRequest('fromusername'), $this->getRequest('tousername'), $title, $description, $musicUrl, $hqMusicUrl, $mediaId));
    }

    /**
     * 回复图文消息
     * @param  array   $items    由单条图文消息类型 NewsResponseItem() 组成的数组
     * @return void
     */
    protected function responseNews($items) {
      exit(new NewsResponse($this->getRequest('fromusername'), $this->getRequest('tousername'), $items));
    }

    /**
     * 分析消息类型，并分发给对应的函数
     *
     * @return void
     */
    public function run() {
      switch ($this->getRequest('msgtype')) {

        case 'event':
          switch ($this->getRequest('event')) {

            case 'subscribe':
              $this->onSubscribe();
              break;

            case 'unsubscribe':
              $this->onUnsubscribe();
              break;
              
             case 'SCAN':
              $this->onScan();
              break;
              
             case 'LOCATION':
              $this->onAutoLocation();
              break;
              
             case 'CLICK':
              $this->onClick();
              break;
              
             case 'VIEW':
              $this->onView();
              break;
              
             case 'scancode_push':
              $this->scancode_push();
              break;
              
             case 'scancode_waitmsg':
              $this->scancode_waitmsg();
              break;
              
             case 'pic_sysphoto':
              $this->pic_sysphoto();
              break;
              
             case 'pic_photo_or_album':
              $this->pic_photo_or_album();
              break;

             case 'pic_weixin':
              $this->pic_weixin();
              break;         
              
             case 'location_select':
              $this->location_select();
              break;
              
              default:
			  $this->onUnknown(); 
              break;

          }

          break;

        case 'text':
          $this->onText();
          break;

        case 'image':
          $this->onImage();
          break;
          
         case 'voice':
          $this->onVoice();
          break;
          
         case 'video':
          $this->onVideo();
          break;

        case 'location':
          $this->onLocation();
          break;

        case 'link':
          $this->onLink();
          break;

        default:
          $this->onUnknown(); 
          break;

      }
        exit('');//防止未关闭连接导致微信发送重复消息
    }
      
  }
  /**
   * 用于回复的基本消息类型
   */
  abstract class WechatResponse {
    protected $toUserName;
    protected $fromUserName;
    public function __construct($toUserName, $fromUserName) {
      $this->toUserName = $toUserName;
      $this->fromUserName = $fromUserName;
    }
    abstract public function __toString();
  }

  /**
   * 用于回复的文本消息类型
   */
  class TextResponse extends WechatResponse {

    protected $content;

    protected $template = <<<XML
<xml>
  <ToUserName><![CDATA[%s]]></ToUserName>
  <FromUserName><![CDATA[%s]]></FromUserName>
  <CreateTime>%s</CreateTime>
  <MsgType><![CDATA[text]]></MsgType>
  <Content><![CDATA[%s]]></Content>
</xml>
XML;

    public function __construct($toUserName, $fromUserName, $content) {
      parent::__construct($toUserName, $fromUserName);
      $this->content = $content;
    }

    public function __toString() {
      return sprintf($this->template,
        $this->toUserName,
        $this->fromUserName,
        time(),
        $this->content
      );
    }

  }


  /**
   * 用于回复的图片消息类型
   */
  class ImageResponse extends WechatResponse {

    protected $media_id;

    protected $template = <<<XML
<xml>
  <ToUserName><![CDATA[%s]]></ToUserName>
  <FromUserName><![CDATA[%s]]></FromUserName>
  <CreateTime>%s</CreateTime>
  <MsgType><![CDATA[image]]></MsgType>
  <Image>
<MediaId><![CDATA[%s]]></MediaId>
</Image>
</xml>
XML;

    public function __construct($toUserName, $fromUserName, $media_id) {
      parent::__construct($toUserName, $fromUserName);
      $this->media_id = $media_id;
    }

    public function __toString() {
      return sprintf($this->template,
        $this->toUserName,
        $this->fromUserName,
        time(),
        $this->media_id
      );
    }

  }


  /**
   * 用于回复的语音消息类型
   */
  class VoiceResponse extends WechatResponse {

    protected $media_id;

    protected $template = <<<XML
<xml>
  <ToUserName><![CDATA[%s]]></ToUserName>
  <FromUserName><![CDATA[%s]]></FromUserName>
  <CreateTime>%s</CreateTime>
  <MsgType><![CDATA[voice]]></MsgType>
  <Voice>
<MediaId><![CDATA[%s]]></MediaId>
</Voice>
</xml>
XML;

    public function __construct($toUserName, $fromUserName, $media_id) {
      parent::__construct($toUserName, $fromUserName);
      $this->media_id = $media_id;
    }

    public function __toString() {
      return sprintf($this->template,
        $this->toUserName,
        $this->fromUserName,
        time(),
        $this->media_id
      );
    }

  }


  /**
   * 用于回复的视频消息类型
   */
  class VideoResponse extends WechatResponse {

    protected $media_id;  
    protected $title;
    protected $description;


    protected $template = <<<XML
<xml>
  <ToUserName><![CDATA[%s]]></ToUserName>
  <FromUserName><![CDATA[%s]]></FromUserName>
  <CreateTime>%s</CreateTime>
  <MsgType><![CDATA[video]]></MsgType>
  <Video>
  	<MediaId><![CDATA[%s]]></MediaId>
    <Title><![CDATA[%s]]></Title>
    <Description><![CDATA[%s]]></Description>
  </Video>
</xml>
XML;

    public function __construct($toUserName, $fromUserName, $media_id,$title='1', $description='2') {
      parent::__construct($toUserName, $fromUserName);
      $this->media_id=$media_id;
      $this->title = $title;
      $this->description = $description;
    }
      
    public function __toString() {
      return sprintf($this->template,
        $this->toUserName,
        $this->fromUserName,
        time(),
        $this->media_id,
        $this->title,
        $this->description
      );
    }

  }


  /**
   * 用于回复的音乐消息类型
   */
  class MusicResponse extends WechatResponse {

    protected $title;
    protected $description;
    protected $musicUrl;
    protected $hqMusicUrl;
    protected $media_id;

    protected $template = <<<XML
<xml>
  <ToUserName><![CDATA[%s]]></ToUserName>
  <FromUserName><![CDATA[%s]]></FromUserName>
  <CreateTime>%s</CreateTime>
  <MsgType><![CDATA[music]]></MsgType>
  <Music>
    <Title><![CDATA[%s]]></Title>
    <Description><![CDATA[%s]]></Description>
    <MusicUrl><![CDATA[%s]]></MusicUrl>
    <HQMusicUrl><![CDATA[%s]]></HQMusicUrl>
    <ThumbMediaId><![CDATA[%s]]></ThumbMediaId>
  </Music>
</xml>
XML;

    public function __construct($toUserName, $fromUserName, $title, $description, $musicUrl, $hqMusicUrl,$media_id) {
      parent::__construct($toUserName, $fromUserName);
      $this->title = $title;
      $this->description = $description;
      $this->musicUrl = $musicUrl;
      $this->hqMusicUrl = $hqMusicUrl;
      $this->media_id=$media_id;
    }

    public function __toString() {
      return sprintf($this->template,
        $this->toUserName,
        $this->fromUserName,
        time(),
        $this->title,
        $this->description,
        $this->musicUrl,
        $this->hqMusicUrl,
        $this->media_id
      );
    }

  }

  /**
   * 用于回复的图文消息类型
   */
  class NewsResponse extends WechatResponse {

    protected $items = array();

    protected $template = <<<XML
<xml>
  <ToUserName><![CDATA[%s]]></ToUserName>
  <FromUserName><![CDATA[%s]]></FromUserName>
  <CreateTime>%s</CreateTime>
  <MsgType><![CDATA[news]]></MsgType>
  <ArticleCount>%s</ArticleCount>
  <Articles>
    %s
  </Articles>
</xml>'
XML;

    public function __construct($toUserName, $fromUserName, $items) {
      parent::__construct($toUserName, $fromUserName);
      $this->items = $items;
    }

    public function __toString() {
      return sprintf($this->template,
        $this->toUserName,
        $this->fromUserName,
        time(),
        count($this->items),
        implode($this->items)
      );
    }

  }

  /**
   * 单条图文消息类型
   */
  class NewsResponseItem {

    protected $title;
    protected $description;
    protected $picUrl;
    protected $url;

    protected $template = <<<XML
<item>
  <Title><![CDATA[%s]]></Title>
  <Description><![CDATA[%s]]></Description>
  <PicUrl><![CDATA[%s]]></PicUrl>
  <Url><![CDATA[%s]]></Url>
</item>
XML;

    public function __construct($title, $description, $picUrl, $url) {
      $this->title = $title;
      $this->description = $description;
      $this->picUrl = $picUrl;
      $this->url = $url;
    }

    public function __toString() {
      return sprintf($this->template,
        $this->title,
        $this->description,
        $this->picUrl,
        $this->url
      );
    }

  }
?>
