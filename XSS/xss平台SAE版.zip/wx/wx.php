<?php
/**
 * 微信公众平台 PHP SDK 示例文件
 *
 * @author NetPuter <netputer@gmail.com>
 */

require('./Wechat.php');
require('./custom.php');

  /**
   * 微信公众平台演示类
   */
  class MyWechat extends Wechat {

    /**
     * 用户关注时触发，回复「欢迎关注」
     *
     * @return void
     */
    protected function onSubscribe() {
        //通过搜索关注时也会发送场景id和ticket，为上次扫描关注时的值，应该是微信服务器缓存的问题，统计扫描场景时不准确
        if (array_key_exists("eventkey",$this->getRequest())){
             $this->responseText('扫码关注');
        }else{
             $this->responseText('搜索关注');
        }
     
    }

    /**
     * 用户取消关注时触发
     *
     * @return void
     */
    protected function onUnsubscribe() {
      // 「悄悄的我走了，正如我悄悄的来；我挥一挥衣袖，不带走一片云彩。」
    }
      
    /**
     * 用户扫描事件时触发
     *
     * @return void
     */
    protected function onScan() {
        //EventKey,事件KEY值，是一个32位无符号整数，即创建二维码时的二维码scene_id
        $this->responseText($this->getRequest('eventkey'));
    }
      
      
    /**
     * 收到地理位置事件时触发
     *
     * @return void
     */
    protected function onAutoLocation() {
        $this->responseText('收到地理消息');
    }
      
      
    /**
     * 用户点击按钮事件时触发
     *
     * @return void
     */
    protected function onClick() {
        $this->responseText($this->getRequest('eventkey'));
    }
      
      
      /**
     * 用户点击网址事件时触发
     * 注意该事件会触发，但是微信不会接受返回内容
     * @return void
     */
    protected function onView() {
                 $this->responseText('view');//这句没效果，对返回内容不处理
    }

    /**
     * 收到文本消息时触发，回复收到的文本消息内容
     *
     * @return void
     */
    protected function onText() {
        $rev=trim($this->getRequest('content'));
        
        if(strlen($rev)<6){
            $this->responseText($rev);
            return;
        }
        
        $validateKey = substr($rev,1,6);
        
        $id=get_sql_userId($validateKey);

        if(empty($id)){
            $this->responseText($rev);
            return;
        }
        
        
        if(startWith($rev,'#')&&strlen($validateKey)==6){//绑定微信号
            
            update_sql_arg("`wx`='".$this->getRequest('fromusername')."',`validated`=1,`validateKey`=NULL",$table='oc_user',"`id`='".$id."'");
            $this->responseText('绑定成功');
            
        }else if(startWith($rev,'!')&&strlen($validateKey)==6){//接触绑定
           
            update_sql_arg("`wx`=NULL,`validated`=0,`validateKey`=NULL",$table='oc_user',"`id`='".$id."'");
            $this->responseText('解绑成功');
        }
        
    }
      
      
     /**
     * 收到语音消息时触发，回复收到的语音消息内容
     *
     * @return void
     */ 
      protected function onVoice() {
          $this->responseVoice($this->getRequest('mediaid'));
    }
      
      
    /**
     * 收到视频消息时触发
     * @return void
     */ 
      protected function onVideo() {
          $this->responseVideo($this->getRequest('mediaid'));
    }

    /**
     * 收到图片消息时触发，回复由收到的图片组成的图文消息
     *
     * @return void
     */
    protected function onImage() {
        
        $this->responseImage($this->getRequest('mediaid'));
        
        /**
      $items = array(
        new NewsResponseItem('标题一', '描述一', $this->getRequest('picurl'), $this->getRequest('picurl')),
        new NewsResponseItem('标题二', '描述二', $this->getRequest('picurl'), $this->getRequest('picurl')),
      );

      $this->responseNews($items);
      **/
    }

    /**
     * 收到地理位置消息时触发，回复收到的地理位置
     *
     * @return void
     */
    protected function onLocation() {
      $this->responseText('收到了位置消息：' . $this->getRequest('location_x') . ',' . $this->getRequest('location_y'));
    }

    /**
     * 收到链接消息时触发，回复收到的链接地址
     *
     * @return void
     */
    protected function onLink() {
      $this->responseText('收到了链接：' . $this->getRequest('url'));
    }
      
     /**
     *  收到扫码推事件的事件推送时触发
     *
     * @return void
     */    
    protected function scancode_push(){
        $ScanCodeInfo= (array) $this->getRequest('scancodeinfo');
        send_custom('收到了扫扫码：'.$ScanCodeInfo['ScanType'] .'-----'.$ScanCodeInfo['ScanResult']);
      }

      /**
     *  收到扫码推事件的事件推送时触发
     *
     * @return void
     */    
    protected function scancode_waitmsg(){
        $ScanCodeInfo= (array) $this->getRequest('scancodeinfo');
        send_custom('收到了扫扫码：'.$ScanCodeInfo['ScanType'] .'-----'.$ScanCodeInfo['ScanResult']);
      }
      
    /**
     * 收到未知类型消息时触发，回复错误，不回复xml形式以防信息泄露
     *
     * @return void
     */
    protected function onUnknown() {
        exit('error');
    }
 }

  $wechat = new MyWechat(get_sql_token());
  $wechat->run();

?>